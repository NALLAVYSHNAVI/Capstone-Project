package com.masai.model;

public class Admin {
	public final Integer id=1;
	public final String username="admin";
	public final String password="admin1234";
}
