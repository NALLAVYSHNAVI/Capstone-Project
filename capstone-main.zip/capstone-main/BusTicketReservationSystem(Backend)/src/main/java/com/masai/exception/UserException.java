package com.masai.exception;

public class UserException extends Exception{
	public UserException() {
		// TODO Auto-generated constructor stub
	}
	
	public UserException(String msg) {
		super(msg);
	}
}
