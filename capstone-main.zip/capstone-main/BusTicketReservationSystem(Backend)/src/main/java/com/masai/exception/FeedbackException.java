package com.masai.exception;

public class FeedbackException extends Exception{
	
	public FeedbackException(){
		
	}
	
	public FeedbackException(String message){
		super(message);
	}

}
