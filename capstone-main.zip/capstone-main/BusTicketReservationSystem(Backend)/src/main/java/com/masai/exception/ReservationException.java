package com.masai.exception;

public class ReservationException extends Exception{

	
	public ReservationException() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	public ReservationException(String mes) {
	
		super(mes);
		
	}
	
}
